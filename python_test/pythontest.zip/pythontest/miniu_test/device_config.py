device_mac_01="94E686016B08"
device_mac_02="94E686016B1C"
device_name_01="小趴菜"
device_name_02="大趴菜"