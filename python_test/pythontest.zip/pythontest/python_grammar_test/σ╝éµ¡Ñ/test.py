import asyncio
async def main():
    # await asyncio.sleep(2)
    print("hello")
    # await asyncio.sleep(10)
    print("nihao")
def pin():
    print("1111")

asyncio.run(main())
pin()
