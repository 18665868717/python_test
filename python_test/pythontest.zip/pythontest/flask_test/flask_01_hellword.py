import flask
from flask import Flask,request,jsonify
# app=Flask(__name__)
#
# @app.route('/hello')
# def hello_world():
#     return "<p>Hello, World!</p>"
#
# if __name__ == '__main__':
#     app.run(host='0.0.0.0',port=5000,debug=True)



# from flask import Flask
# app = Flask(__name__)
#
# @app.route('/blog/<int:postID>')
# def show_blog(postID):
#    return 'Blog Number %d' % postID
#
# @app.route('/rev/<float:revNo>')
# def revision(revNo):
#    return 'Revision Number %f' % revNo
#
# if __name__ == '__main__':
#    app.run(debug=True)


#
# from flask import abort, redirect, url_for
# app=Flask(__name__)
#
# """重定向"""
# @app.route('/')
# def index():
#     return redirect(url_for('login'))
#
# @app.route('/login')
# def login():
#     abort(401,"title")

"""url构建"""
from flask import url_for,session
from werkzeug.utils import redirect

app = Flask(__name__)
app.secret_key="lizepeng"
@app.route('/')
def index():
    return 'index'

@app.route('/login')
def login():
    return 'login'

@app.route('/user/<username>')
def profile(username):
    return f'{username}\'s profile'

@app.route('/bilibili')
def bilibili():
    return redirect("https://www.baidu.com")

@app.route('/get',methods=['GET'])
def get_req():
    return "get请求"

@app.route('/test',methods=['POST'])
def post_req():
    try:
        my_json=request.get_json()
        print(my_json)
        app.logger.debug("错误")
        get_name=my_json.get("name")
        get_age=my_json.get("age")
        if not all([get_age,get_name]):
            return jsonify(msg="缺少参数")
        return  jsonify(name=get_name,age=get_age)
    except Exception as e:
        print(e)
        return jsonify(msg="出错了哦")

"""sessions会话"""
#登录
@app.route("/try/login",methods=["POST"])
def login_test():
    get_data=request.get_json()
    username=get_data.get("username")
    password=get_data.get("password")

    if not all([username,password]):
        return jsonify(msg="参数错误")
    if username=="admin" and password=="admin":
        #如果通过验证 保存登录状态在session中
        session["username"]=username
        return """<p>登录成功</p>"""
    else:
        return jsonify(mes="账号密码错误")
#退出
@app.route("/try/loginout",methods=["GET"])
def loginout_test():
    session.clear()
    return jsonify(msg="退出成功")
#检查登录状态
@app.route("/session",methods=["GET"])
def check_session():
    username=session.get("username")
    if username is not None:
        return jsonify(key=username)
    else:
        return jsonify(mes="出错了")

with app.test_request_context():
    print(url_for('index'))
    print(url_for('login'))
    print(url_for('login', next='/'))
    print(url_for('profile', username='John Doe'))
if __name__ == '__main__':

    app.run(host='0.0.0.0',port=5001,debug=True)


