list=[('u',9),('p',7)]
list1=[[1,2,3],[4,5,6]]
for i ,j  in list:
    print(i,j)
for m,n,b in list1:
    print(m,n,b)