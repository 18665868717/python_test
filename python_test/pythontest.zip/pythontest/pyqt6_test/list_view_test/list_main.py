import sys
import PyQt5.QtWidgets as qw

import pyqt_list_view
from PyQt5.QtCore import QStringListModel,QAbstractListModel,QModelIndex,QSize
class my_list_v(qw.QMainWindow,pyqt_list_view.Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)

        name_list=["测试1","测试2","测试3","测试4"]
        list_mode=QStringListModel()
        list_mode.setStringList(name_list)
        self.listView.setModel(list_mode)
if __name__ == '__main__':
    app=qw.QApplication(sys.argv)
    my=my_list_v()
    my.show()
    sys.exit(app.exec())