from time import sleep
from tkinter import *

# root = Tk()
# w = Canvas(root, width=200, height=200)
# w.pack()
# data=[190, 200, 190, 100]
# var = w.create_line(data)
# w.update()
# sleep(1)
# w.create_line(190, 200, 190, 150)
# # w.coords(var, )
# # w.coords(var, 190, 200, 190, 150)
#
# root.mainloop()
#

# from tkinter import *
#
# # Initialize an instance of tkinter window
# root=Tk()
# # Set the width and height of the tkinter window
# root.geometry("200x200")
# # Create a canvas widget
# canvas=Canvas(root, width=200, height=200)
# canvas.pack()
# data=[[190, 200, 190, 150],[180, 25,180 ,200]]
# # Create a line in canvas widget
# for i in data:
#     # x0=i[0]-1
#     # y0=i[1]
#     # xn=i[2]-1
#     # yn=i[3]
#     uid=canvas.create_line(i,width=2)
#     # canvas.moveto(uid,y=0,x=+1)
#     x0=i[0]-1
#     y0=i[1]
#     xn=i[2]-1
#     yn=i[3]
#     # canvas.create_line(x0,y0,xn,yn)
#     canvas.update()
#     canvas.coords(x0,y0,xn,yn,uid)
#     sleep(2)
# # Create a dashed line
# # canvas.create_line(180, 25,180 ,200,fill='red',width=2)
# root.mainloop()


import  tkinter

class gui(tkinter.Tk):

    # def draw_background(self):
    #     self.canvas.create_oval(0,0, 500, 500, fill = 'black')

    def draw_circle(self,x_start,y_start,x_end,y_end):
        self.canvas.create_line(x_start,y_start,x_end,y_end, fill = 'red')



    def __init__(self, parent):
        tkinter.Tk.__init__(self, parent)
        self.guiHeight = 800
        self.guiWidth = 800
        self.initialise()

    def animation(self):
        self.x_start = self.x_start + 2 % 100
        self.x_end = self.x_end + 2 % 100

        self.canvas.delete("all")
        # self.draw_background()
        self.draw_circle(self.x_start,self.y_start,self.x_end,self.y_end)

        self.after(1000,self.animation)

    def initialise(self):
        self.title('信号图')

        self.canvas = tkinter.Canvas(self, height = self.guiHeight, width = self.guiWidth)
        # self.draw_background()
        self.canvas.pack()

        self.x_start = 0
        self.x_end= 0
        self.y_start=400
        self.y_end=800

        self.after(1000, self.animation)
        self.mainloop()


if __name__ =="__main__":
    app = gui(None)


















    # import tkinter
    #
    #
    # class gui(tkinter.Tk):
    #
    #     # def draw_background(self):
    #     #     self.canvas.create_oval(0,0, 500, 500, fill = 'black')
    #
    #     def draw_circle(self, x, y):
    #         self.canvas.create_oval(x, y, x + 10, y + 10, fill='green')
    #
    #     def __init__(self, parent):
    #         tkinter.Tk.__init__(self, parent)
    #         self.guiHeight = 800
    #         self.guiWidth = 800
    #         self.initialise()
    #
    #     def animation(self):
    #         self.x = self.x + 1 % 100
    #         self.y = self.y + 1 % 100
    #
    #         self.canvas.delete("all")
    #         # self.draw_background()
    #         self.draw_circle(self.x, self.y)
    #
    #         self.after(100, self.animation)
    #
    #     def initialise(self):
    #         self.title('traffic')
    #
    #         self.canvas = tkinter.Canvas(self, height=self.guiHeight, width=self.guiWidth)
    #         # self.draw_background()
    #         self.canvas.pack()
    #
    #         self.x = 500
    #         self.y = 0
    #         self.after(100, self.animation)
    #         self.mainloop()
    #
    #
    # if __name__ == "__main__":
    #     app = gui(None)