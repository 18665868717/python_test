import crypt
content=crypt.crypt('egg',"HX")
print(content)
print(len(content))
# print(800%100)
