import sys
from telnetlib import EC
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import NoSuchElementException, TimeoutException
from selenium import webdriver
from selenium.webdriver.support.wait import WebDriverWait

from ddt import file_data,ddt
from selenium.webdriver.common.by import By
from time import sleep
import unittest
from selenium.webdriver.support import expected_conditions as EC


class Test_loging(unittest.TestCase):

    def setUp(self):

        self.driver= webdriver.Chrome('/usr/local/bin/chromedriver')
        self.driver.get('https://zuankeba.cn/')
        self.driver.maximize_window()
        self.driver.implicitly_wait(30)
        sleep(1)


    def test_login_methon(self):
        print("111")

    def tearDown(self):
        sleep(3)
        self.driver.quit()
    # @classmethod
    # def tearDownClass(cls) -> None:
    #     cls.driver.quit()



if __name__ == '__main__':
    unittest.main()
